<?php
header("location:accueil/menu");

?>