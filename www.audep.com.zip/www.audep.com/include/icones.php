<link rel="stylesheet" href="../../../source/icones/css/v4-shims.min.css">
<link rel="stylesheet" href="../../../source/icones/css/all.min.css">
<link rel="stylesheet" href="../../../source/icones/css/fontawesome.min.css">
<link rel="stylesheet" href="../../../source/icones/css/brands.min.css">
<link rel="stylesheet" href="../../../source/icones/css/regular.min.css">
<link rel="stylesheet" href="../../../source/icones/css/solid.min.css">
<link rel="stylesheet" href="../../../source/icones/css/svg-with-js.min.css">