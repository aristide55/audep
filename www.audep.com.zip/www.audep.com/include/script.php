<script type="text/javascript" src="../../../source/js/plugins/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="../../../source/js/materialize.min.js"></script>
<script type="text/javascript" src="../../../source/js/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="../../../source/js/plugins/fullcalendar/lib/moment.min.js"></script>
<script type="text/javascript" src="../../../source/js/plugins.min.js"></script>
<script type="text/javascript" src="../../../source/js/plugins/prism/prism.js"></script>
<script type="text/javascript" src="../../../source/js/plugins/chartist-js/chartist.min.js"></script>