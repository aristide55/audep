CREATE DATABASE smartwork CHARACTER SET 'utf8';
USE smartwork;

CREATE TABLE Services(
    id_services INT(11) PRIMARY KEY auto_increment NOT null,
    nom VARCHAR(50),
    categories VARCHAR(50),
    details VARCHAR(255)
)Engine=Innodb;

CREATE TABLE Categories(
    id_categories INT(11) PRIMARY KEY auto_increment NOT null,
    nom VARCHAR(50),
    details VARCHAR(255)
)Engine=Innodb;

CREATE TABLE Prestataire (
    id_prestataire int auto_increment PRIMARY key not null,
    nom VARCHAR(50),
    prenoms VARCHAR(50),
    date_nais DATE,
    contact VARCHAR(20),
    email VARCHAR(50),
    localisation VARCHAR(50),
    services VARCHAR(20),
    categories VARCHAR(50),
    annee_exp int(11)
)Engine=Innodb;


CREATE TABLE Administrateur (
    id_admin int auto_increment PRIMARY key not null,
    nom VARCHAR(50),
    prenoms VARCHAR(50),
    contact VARCHAR(20),
    pass VARCHAR(50)
)Engine=Innodb;