<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>SmartWork | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>

<body class="row grey-text">
<div class="col l8 white liste">
    <h5 class="grey-text">Liste</h5>
<div class="col s12">
                    <ul class="tabs tab-demo z-depth-1" style="width: 100%;">
                      <li class="tab col s3"><a class="active" href="#test1">Maison</a>
                      </li>
                      <li class="tab col s3"><a href="#test2" class="">Domestique</a>
                      </li>
                      <li class="tab col s3"><a href="#test3" class=""></a>
                      </li>
                      <li class="tab col s3"><a href="#test4" class="">Test 4</a>
                      </li>
                    <div class="indicator" style="right: 580px; left: 0px;"></div><div class="indicator" style="right: 580px; left: 0px;"></div></ul>
                  </div>
                  <div class="col s12">
                    <div id="test1" class="col s12" style="display: block;">
                      <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
                      <ol>
                        <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
                        <li>Aliquam tincidunt mauris eu risus.</li>
                        <li>Vestibulum auctor dapibus neque.</li>
                      </ol>
                    </div>
                    <div id="test2" class="col s12" style="display: none;">
                      <dl>
                        <dt>Definition list</dt>
                        <dd>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</dd>
                        <dt>Lorem ipsum dolor sit amet</dt>
                        <dd>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</dd>
                      </dl>
                    </div>
                    <div id="test3" class="col s12" style="display: none;">
                      <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies
                        mi vitae est. Mauris placerat eleifend leo.</p>
                    </div>
                    <div id="test4" class="col s12" style="display: none;">
                      <ul>
                        <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
                        <li>Aliquam tincidunt mauris eu risus.</li>
                        <li>Vestibulum auctor dapibus neque.</li>
                      </ul>
                    </div>
                  </div>
</div>



<?php require_once '../../../include/script.php'; ?>

    <script src="main.js"></script>

</body>

</html>
