<?php

require_once '../../get/connexion.php';
$nom = $_POST['nom'];
$details = $_POST['details'];

$ajout = $bd->prepare('INSERT INTO Categories VALUES(NULL,?,?)');
$ajout->execute(array(
    $nom,
    $details,
));
header('location:../');
