<?php

require_once '../../get/connexion.php';
$nom = $_POST['nom'];
$categories = $_POST['categories'];
$details = $_POST['details'];

$ajout = $bd->prepare('INSERT INTO Services VALUES(NULL,?,?,?)');
$ajout->execute(array(
    $nom,
    $categories,
    $details,
));
header('location:../');
