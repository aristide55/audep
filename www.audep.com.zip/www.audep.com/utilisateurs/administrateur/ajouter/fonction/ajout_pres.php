<?php

require_once '../../get/connexion.php';
$nom = $_POST['nom'];
$prenoms = $_POST['prenoms'];
$date_nais = $_POST['date_nais'];
$contact = $_POST['contact'];
$email = $_POST['email'];
$annee_exp = $_POST['annee_exp'];
$services = $_POST['services'];
$categories = $_POST['categories'];
$localisation = $_POST['localisation'];

$ajout = $bd->prepare('INSERT INTO Prestataire VALUES(NULL,?,?,?,?,?,?,?,?,?)');
$ajout->execute(array(
    $nom,
    $prenoms,
    $date_nais,
    $contact,
    $email,
    $localisation,
    $services,
    $categories,
    $annee_exp,
));
header('location:../');
