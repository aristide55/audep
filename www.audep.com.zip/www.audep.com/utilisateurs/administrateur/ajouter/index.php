<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>SmartWork | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>
<style>

</style>
<body class="row grey-text">
    <div id="fond">

    </div>
    <div class="col l12 s12 m12">

            <a class="carte" href="prestataires.php"><div class="col m3 offset-m1 s3">
                <div class="card white-grey z-depth-0">
                    <div class="card-content grey-text center">
                        <i class="mdi-social-person-add fa-6x cyan-text"></i>
                        <p>
                        <span class="card-title cyan-text"><b class="">Prestataires</b></span>
                        </p>
                        <p>Enregistrer un nouveau prestataire, associer lui une categorie et un services</p>
                    </div>
                </div>
            </div>
            </a>
            <a class="carte" href="services.php"><div class="col m3 s3">
                <div class="card white-grey z-depth-0">
                    <div class="card-content grey-text center">
                        <i class="mdi-action-settings-applications fa-6x pink-text"></i>
                        <p>
                        <span class="card-title pink-text"> <b class="">Services</b></span>
                        </p>
                        <p>Ajouter un service, attribuez lui une categorie et enrichissez vos services</p>
                    </div>
                </div>
            </div>
            </a>
            <a class="carte" href="categories.php"><div class="col m3 s3">
                <div class="card white-grey z-depth-0">
                    <div class="card-content grey-text center">
                        <i class="mdi-action-shop fa-6x green-text"></i>
                        <p>
                        <span class="card-title green-text"> <b class="">Categories</b></span>
                        </p>
                        <p>Elargissez vos domaines d'actions en ajoutant une nouvelle categorie</p>
                    </div>
                </div>
            </div>
            </a>
           
        </div>
    </div>

        <?php require_once '../../../include/script.php'; ?>

        <script src="main.js"></script>
    
    </body>

    </html>