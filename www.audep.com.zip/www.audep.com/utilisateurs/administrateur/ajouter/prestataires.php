<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Ajout | Prestataires</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>
<style>

</style>

<body class="row grey-text">
    <div id="fond">

    </div>
    <div class="col m12">
        <h2 class="cyan white-text fa-2x col m3"> <b>Ajouter | Prestataire</b></h2>
    </div>
    <form id="form_prest" action="fonction/ajout_pres.php" method="post" class="col m8 offset-m1 white">
        <div class="input-field col m6">
            <i class="mdi-action-account-circle prefix cyan-text"></i>
            <input id="nom" type="text" name="nom">
            <label for="nom" class="">Nom</label>
        </div>
        <div class="input-field col m6">
            <i class="mdi-action-account-circle prefix cyan-text"></i>
            <input id="prenoms" type="text" name="prenoms">
            <label for="prenoms" class="">Prenoms</label>
        </div>
        <div class="input-field col m6">
            <i class="mdi-notification-event-note prefix cyan-text"></i>
            <input id="date_nais" type="date" name="date_nais">
            <label for="date_nais" class=""></label>
        </div>
        <div class="input-field col m6">
            <i class="mdi-communication-call prefix cyan-text"></i>
            <input id="conctact" type="text" name="contact">
            <label for="conctact" class="">Contact</label>
        </div>
        <div class="input-field col m6">
            <i class="mdi-communication-email prefix cyan-text"></i>
            <input id="e_mail" type="email" name="email">
            <label for="e_mail" class="">Mail</label>
        </div>
        <div class="input-field col m6">
            <i class="mdi-communication-location-on prefix cyan-text"></i>
            <input id="localisation" type="text" name="localisation">
            <label for="localisation" class="">Localisation</label>
        </div>
        <div class="input-field col m6">
            <i class="mdi-action-settings-applications prefix cyan-text"></i>
            <input id="service" type="text" name="services">
            <label for="service" class="">Service</label>
        </div>
        <div class="input-field col m6">
            <i class="mdi-action-shop prefix cyan-text"></i>
            <input id="categorie" type="text" name="categories">
            <label for="categorie" class="">Categorie</label>
        </div>
        <div class="input-field col m6 offset-m3">
            <i class="mdi-notification-event-available prefix cyan-text"></i>
            <input id="annee_exp" type="number" name="annee_exp">
            <label for="annee_exp" class="">Annee d'experience</label>
        </div>
    </form>
    <div class="col m8 offset-m2">
        <a href="#" class="waves-effect waves-light btn cyan col m3 offset-m7" id="send"><i class="mdi-social-person-add left"></i>Ajouter</a>
    </div>

    <?php require_once '../../../include/script.php'; ?>

    <script src="main.js"></script>
    <script>
        $('#send').click(function() {
            $('#form_prest').submit()
        })
    </script>
</body>

</html>