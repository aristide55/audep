<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Ajout | Prestataires</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>
<style>

</style>

<body class="row grey-text">
    <div id="fond">

    </div>
    <div class="col m12">
        <h2 class="green white-text fa-2x col m3"> <b>Ajouter | Categorie</b></h2>
    </div>
    <form id="form_prest" action="fonction/ajout_categories.php" method="post" class="col m8 offset-m1 white">
        <div class="input-field col m6 offset-m3">
            <i class="mdi-editor-mode-edit prefix green-text"></i>
            <input id="nom" type="text" name="nom">
            <label for="nom" class="">Nom</label>
        </div>
        <div class="input-field col m6 offset-m3">
            <i class="mdi-editor-mode-edit prefix green-text"></i>
            <textarea name="details" id="details" class="materialize-textarea"></textarea>
            <label for="details" class="">description</label>
        </div>
    </form>
    <div class="col m8 offset-m2">
        <a href="#" class="waves-effect waves-light btn green col m3 offset-m7" id="send"><i class="mdi-social-person-add left"></i>Ajouter</a>
    </div>

    <?php require_once '../../../include/script.php'; ?>

    <script src="main.js"></script>
    <script>
        $('#send').click(function() {
            $('#form_prest').submit()
        })
    </script>
</body>

</html>