<?php
    try {
        $bd = new PDO('mysql:host=localhost;dbname=smartwork', 'dy', '785942163');
    } catch (Exception $e) {
        die('Erreur : '.$e->getMessage());
    }
