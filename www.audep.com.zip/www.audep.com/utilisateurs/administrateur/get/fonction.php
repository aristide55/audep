<?php

function getCategories()
{
    global $bd;
    $cat = $bd->query('SELECT *FROM Categories');

    return $cat;
}
