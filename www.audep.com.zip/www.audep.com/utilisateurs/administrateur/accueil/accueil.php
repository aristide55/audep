<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>SmartWork | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>

<body class="row white grey-text">
    <div id="fond">

    </div>
    <ul id="slide-out" class="side-nav fixed z-depth-0">
        <li class="grey">
            <div class="user-view">
                <div class="background">
                    <img src="">
                </div>
                <a href="#!usuario"><img class="circle" src=""></a>
                <a href="#!nombre"><span class="white-text name">Jonathan Moreno</span></a>
                <a href="#!email"><span class="white-text email">jmore83@gmail.com</span></a>
            </div>
        </li>
        <li><a class="" href="" data-url="../ajouter">Ajouter</a></li>
        <li><a class="" href="" data-url="../liste">Liste</a></li>
        <li>
            <div class="divider"></div>
        </li>
        <li><a class="" href="">Statistiques</a></li>
        <li>
            <div class="divider"></div>
        </li>
        <li><a class="" href="">Deconnexion</a></li>
    </ul>
    <iframe id="fr" src="../ajouter" frameborder="0" class="col l10 offset-l2"></iframe>

    <?php require_once '../../../include/script.php'; ?>

    <script src="main.js"></script>

</body>

</html>