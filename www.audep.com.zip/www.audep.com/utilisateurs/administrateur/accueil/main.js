$('a').click(function() {
    $('#fr').attr('src', this.dataset.url)
    return false
})