<?php

header('location:accueil.php');
