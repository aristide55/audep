<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>AUDEP | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>

<body class="row white grey-text text-darken-3">
    <div id="fond">

    </div>
    <?php require_once '../menu.php'; ?>
    <div class="col l8 offset-l2" id="equipe">
        <div class="col l12">
            <img src="../../../source/images/1.jpg" alt="" class="responsive-img"/>
        </div>
        <div class="col l4">
            <div id="profile-card" class="card">
                <div class="card-image waves-effect waves-block waves-light">
                    <img class="" src="../../../source/images/1.jpg" alt="user background">
                </div>
                <div class="card-content">
                    <span class="card-title activator grey-text text-darken-4">KOUAKOU Ange</span>
                    <p><i class="mdi-action-perm-identity cyan-text text-darken-2"></i>Seretaire du DG</p>
                    <p><i class="mdi-action-perm-phone-msg cyan-text text-darken-2"></i> +1 (612) 222 8989</p>
                    <p><i class="mdi-communication-email cyan-text text-darken-2"></i> mail@domain.com</p>

                </div>
            </div>
        </div>
        <div class="col l4">
            <div id="profile-card" class="card">
                <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="../../../source/images/1.jpg" alt="user background">
                </div>
                <div class="card-content">
                    <span class="card-title  grey-text text-darken-4">KOUAKOU Rene</span>
                    <p><i class="mdi-action-perm-identity cyan-text text-darken-2"></i>Responsable informatique</p>
                    <p><i class="mdi-action-perm-phone-msg cyan-text text-darken-2"></i> +1 (612) 222 8989</p>
                    <p><i class="mdi-communication-email cyan-text text-darken-2"></i> mail@domain.com</p>

                </div>
            </div>
        </div>
        <div class="col l4">
                <div id="profile-card" class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="" src="../../../source/images/1.jpg" alt="user background">
                    </div>
                    <div class="card-content">
                        <span class="card-title  grey-text text-darken-4">KONE ABOU</span>
                        <p><i class="mdi-action-perm-identity cyan-text text-darken-2"></i>Directeur informatique</p>
                        <p><i class="mdi-action-perm-phone-msg cyan-text text-darken-2"></i> +1 (612) 222 8989</p>
                        <p><i class="mdi-communication-email cyan-text text-darken-2"></i> mail@domain.com</p>
    
                    </div>
                </div>
            </div>
            <div class="col l4">
                    <div id="profile-card" class="card">
                        <div class="card-image waves-effect waves-block waves-light">
                            <img class="" src="../../../source/images/1.jpg" alt="user background">
                        </div>
                        <div class="card-content">
                           <span class="card-title  grey-text text-darken-4">LAMINE DIAKITE</span>
                            <p><i class="mdi-action-perm-identity cyan-text text-darken-2"></i>Infographe</p>
                            <p><i class="mdi-action-perm-phone-msg cyan-text text-darken-2"></i> +1 (612) 222 8989</p>
                            <p><i class="mdi-communication-email cyan-text text-darken-2"></i> mail@domain.com</p>
        
                        </div>
                    </div>
                </div>
                <div class="col l4">
                        <div id="profile-card" class="card">
                            <div class="card-image waves-effect waves-block waves-light">
                                <img class="" src="../../../source/images/1.jpg" alt="user background">
                            </div>
                            <div class="card-content">
                               <span class="card-title  grey-text text-darken-4">DIGBEU PATRICK</span>
                                <p><i class="mdi-action-perm-identity cyan-text text-darken-2"></i>Responsable Marketing</p>
                                <p><i class="mdi-action-perm-phone-msg cyan-text text-darken-2"></i> +1 (612) 222 8989</p>
                                <p><i class="mdi-communication-email cyan-text text-darken-2"></i> mail@domain.com</p>
            
                            </div>
                        </div>
                    </div>
                    <div class="col l4">
                            <div id="profile-card" class="card">
                                <div class="card-image waves-effect waves-block waves-light">
                                    <img class="" src="../../../source/images/1.jpg" alt="user background">
                                </div>
                                <div class="card-content">
                                    <span class="card-title  grey-text text-darken-4">N'GORAN ANNE</span>
                                    <p><i class="mdi-action-perm-identity cyan-text text-darken-2"></i>Commerciale</p>
                                    <p><i class="mdi-action-perm-phone-msg cyan-text text-darken-2"></i> +1 (612) 222 8989</p>
                                    <p><i class="mdi-communication-email cyan-text text-darken-2"></i> mail@domain.com</p>
                
                                </div>
                            </div>
                        </div>
    </div>
    <?php require_once '../pieds.php'; ?>
    <?php require_once '../../../include/script.php'; ?>

    <script src="main.js"></script>

</body>

</html>