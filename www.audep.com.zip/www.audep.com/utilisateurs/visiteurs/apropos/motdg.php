<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>AUDEP | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>

<body class="row white white-text">
    <div id="fond">

    </div>
    <?php require_once '../menu.php'; ?>

    <div class="col l8 offset-l2" id="mot">
        <div class="col l3">
            <img src="../../../source/images/dg.png" id="img" alt="" class="responsive-img" />
            <h6><b>Armand AJAVON</b></h6>
            <b>
                <h6>Directeur Général</h6>
            </b>
        </div>
        <div class="col l9">
            <h3 class="flow-text">Mot du Directeur</h3>
            <p>
                L’architecture,une profession reliant à la fois art de vivre et science, se pose comme l’un des métiers
                les plus complexes en termes de création et de réalisation. Faire de l’architecture est un acte
                individuel, demandant une dextérité et une ouverture d’esprit, afin d’avoir une répercussion sur la
                société. La démarche doit être rationnelle, sans pour autant inhiber la création. L’architecture
                découle d’un courant de pensées cosmopolite, adapté à un lieu, et une clientèle spécifique.
            </p>
            <p>
                Chacun, fort de l’expérience vécue, arrive à trouver son équilibre parmi ces dualités, sa façon de
                faire. De ce choc de
                pensées en découlera une réalisation épurée au gout de tous.
            </p>
            
        </div>
        <p>
                La meilleure voie aujourd’hui reste le travail d’équipe, chacun apporte son savoir-faire, sa vision,
                son tempérament et sa manière de penser. Des divergences qui sont perçu comme une qualité, pour un
                collectif bien huilé. Tous ces aspects forment le secret du passage de l’imagination à la réalisation.
            </p>
        <div class="col l12">

            <h3 class="flow-text col l9 offset-l3">Presentation de l'équipe</h3>
            <p>
                Fondé depuis 1978 par un groupe de quatre jeunes architectes diplômés de la facultéd’architecture de
                l’Université de Montréal, Canada, dont M. AJAVON Armand était le chef de file, AUDEP International
                s’est aussitôt distingué lors d’un concours mondial organisé à Mexico par l’Union International des
                Architectes (UIA). Le directeur d’AUDEP International capitalise aujourd’hui 30 années d’expérience
                dans le domaine de l’Architecture, de l’Urbanisme, du Design et de l’aménagement paysager. Ses
                réalisations dans plusieurs pays de la sous-région portent sur, les sièges sociaux, les opérations
                immobilières et les résidences individuelles, étudiées avec un accent particulier sur l’environnement,
                la ventilation, la lumière, l’eau et l’utilisation des matériaux. Dans son
                approche, AUDEP International considère que chaque client est unique, ce qui lui permet de
                personnaliser chaque projet et obtenir ses formes architecturales
                variées. Par ailleurs, M. AJAVON à travers sa longue expérience acquise en Amérique du Nord, en Italie
                Afrique, notamment aux Grands travaux et au BNEDT,
                ou il a occupé d’importantes fonctions en Urbanisme et en montage de grands projets d’intérêt national,
                s’intéresse aux grands ensembles immobiliers
                mixtes, et aménagement touristique. L’équipe qu’il dirige est essentiellement composée de jeunes
                talents dynamiques qui maitrisent les nouvelles techniques
                d’expression graphique et l’utilisation des matériaux. Elle travaille sur les relations entre le bâti
                et le naturel, entre l’intérieur et l’extérieur. Son style très contemporain allie modernisme et
                africanité tout en restant dans les limites financières raisonnables.
            </p>
        </div>
    </div>
    <?php require_once '../pieds.php'; ?>   
    <?php require_once '../../../include/script.php'; ?>

    <script src="main.js"></script>

</body>

</html>