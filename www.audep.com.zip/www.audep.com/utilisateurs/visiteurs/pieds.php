<footer id="footer" class="page-footer col l12 black" style="margin-bottom:-1cm;margin-top:0cm;opacity:0.9;">
        <div class="">
            <div class="row">
                <div class="col l4">
                    <h3 class="orange-text" style="font-weight:bold">AUDEP</h3>
                    <h6 class="white-text">Architecture, Urbanisme, Design, Engineering et Paysage</h6>
                </div>
                <div class="col l4 white-text">
                    <div class="col l12 row" style="margin-top:1cm">
                    <span class="fa fa-map-marker fa-2x col l1 red-text" style="font-size:35px;opacity:0.7"> </span>
                    <div class="col l11">
                    <span class="col l12" style="font-size:15px">Plateau Cité Esculape,1er batiment,1er étage</span>
                    <span class="col l12" style="font-size:20px;font-weight:bold">Abidjan, Côte d'ivoire</span>
                    </div>
                    </div>
                    <div class="col l12 row" style="margin-top:0cm">
                    <span class="fa fa-phone fa-2x col l1 green-text" style="font-size:35px;opacity:0.7"> </span>
                    <div class="col l11">
                    <span class="col l12" style="font-size:20px; font-weight:bold">+255 20 65 74 55</span>
                    </div>
                    </div>
                    <div class="col l12 row" style="margin-top:0cm">
                    <span class="fa fa-envelope fa-2x col l1 white-text" style="font-size:35px;opacity:0.7"> </span>
                    <div class="col l11">
                    <span class="col l12 blue-text" style="font-size:20px; font-weight:bold">audepintersarl@gmail.com</span>
                    </div>
                    </div>
                </div>
                <div class="col l4">
                    <h5 class="white-text" style="font-weight:bold">A propos de nous</h5>
                    <p class="grey-text text-lighten-4">AUDEP est un Bureau d'Etudes dont les activités couvrent les secteurs de l'Architecture, l'Urbanisme, le Design, l'Engineering, et le Paysagisme.
Son expérience réside dans le design urbain, la planification urbaine et régionale, le design des ensembles commerciaux, éducatifs et respectifs.
Il s’intéresse aux domaine du B.T.P.(Bâtiment et Travaux Publics) et compte plusieurs projets à son actif, allant des résidences privées aux infrastructures publiques importantes.</p>
                </div>
                
            </div>
        </div>
        <div class="footer-copyright">
            <div class="">
                © 2019 Copyright AUDEP
                <a class="grey-text text-lighten-4 right" href="#!">Designed by Edy KOFFI</a>
            </div>
        </div>
    </footer>
