<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>AUDEP | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>

<body class="row black">
    <?php require_once '../menu.php'; ?>
<div class="col l12" id="slide">
<div class="col l1 gauche">
    <i class="mdi-hardware-keyboard-arrow-left fa-5x white-text"></i>
</div>
<div class="col l10" id="nom">
    <h3 class="white-text col l6 offset-l3 center"><b>Immeuble Volant</b></h3>
    <h5 class="col l6 offset-l3 flow-text center white">Abidjan, Treichville, Gare de bassam</h5>
</div>
<div class="col l1 droit">
    <i class="mdi-hardware-keyboard-arrow-right fa-5x white-text"></i>
</div>
</div>
<div class="col l12 grey lighten-2">
    <div class="col l10 offset-l1">
        <div class="col l2">
    <img src="../../../source/images/2.jpg" alt="" class="responsive-img"/>            
        </div>
        <div class="col l2">
    <img src="../../../source/images/5.jpg" alt="" class="responsive-img"/>            
        </div>
        <div class="col l2">
    <img src="../../../source/images/10.jpg" alt="" class="responsive-img"/>            
        </div>
        <div class="col l2">
    <img src="../../../source/images/9.jpg" alt="" class="responsive-img"/>            
        </div>
        <div class="col l2">
    <img src="../../../source/images/1.jpg" alt="" class="responsive-img"/>            
        </div>
        <div class="col l2">
    <img src="../../../source/images/13.jpg" alt="" class="responsive-img"/>            
        </div>
    </div>
</div>
<div class="col l12 grey lighten-5">
    <div class="col l7">
        <h5 class="grey-text text-darken-3 flow-text"><b>Immeuble volant</b></h5>
        <h6 class="grey-text">Projet de construction realise en chine</h6>
        <p class="grey-text col l9">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione delectus sequi sapiente doloremque laborum ab blanditiis laboriosam quaerat molestiae pariatur assumenda, ipsam architecto? Tempora enim eligendi ipsam, error tenetur velit!
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facere aliquam voluptatem eius magnam incidunt labore odio, illum aliquid iusto earum laboriosam quis iure cumque modi voluptas id doloribus fuga suscipit!
        </p>
    </div>
    <div class="col l5 grey-text" id="details">
    <h5 class="grey-text text-darken-3 flow-text"><b>Caracteristiques</b></h5>
        <p>Pays : Cote d'ivoire</p>
        <p>Ville : Cote d'ivoire</p>
        <p>Superficie : Cote d'ivoire</p>
        <p>Budget : 1000 000 000 cfa</p>
        <p>Delay : 30 jours</p>
        <p>Partenaires : BOllore cote d'ivoire<br>
                        Solibra<br>
                        Ivoire kig<br>
                        Ivoire kig<br>
    
    </p>
        <p>Date de debut : 04 Janvier 2019</p>
        <p>Date de fin : 11 fevrier 2019</p>

        
    </div>
</div>
 <?php require_once '../pieds.php'; ?>
 <?php require_once '../../../include/script.php'; ?>
 <script>
     $('.responsive-img').on('mouseover', function() {
    $('#slide').attr('style', "background: url("+ this.src + ");background-size: 100%;background-repeat: no-repeat;background-position: 0 -5cm;")
})
 </script>

</body>
</html>