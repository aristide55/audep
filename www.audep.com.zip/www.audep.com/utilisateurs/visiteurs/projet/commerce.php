<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>AUDEP | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>

<body class="row black">
    <?php require_once '../menu.php'; ?>
<div class="col l12">
<div class="col l3">
<div class="col s12 m6 grid">
<figure class="effect-marley">
<img src="../../../source/images/2.jpg" alt="img11">
<figcaption>
<h5><b>Immeuble<span> volant</span></b></h5>
<p>Milo went to the woods. He took a fun ride and never came back.</p>
<a href="commerce_list.php">View more</a>
</figcaption>     
</figure>
</div>
</div>
<div class="col l3">
<div class="col s12 m6 grid">
<figure class="effect-marley">
<img src="../../../source/images/1.jpg" alt="img11">
<figcaption>
<h5><b>Plan<span> de Design</span></b></h5>
<p>Milo went to the woods. He took a fun ride and never came back.</p>
<a href="#">View more</a>
</figcaption>     
</figure>
</div>
</div>
<div class="col l3">
<div class="col s12 m6 grid">
<figure class="effect-marley">
<img src="../../../source/images/4.jpg" alt="img11">
<figcaption>
<h5><b>New<span> city</span></b></h5>
<p>Milo went to the woods. He took a fun ride and never came back.</p>
<a href="#">View more</a>
</figcaption>     
</figure>
</div>
</div>
<div class="col l3">
<div class="col s12 m6 grid">
<figure class="effect-marley">
<img src="../../../source/images/10.jpg" alt="img11">
<figcaption>
<h5><b>Free<span> House</span></b></h5>
<p>Milo went to the woods. He took a fun ride and never came back.</p>
<a href="#">View more</a>
</figcaption>     
</figure>
</div>
</div>
<div class="col l3">
<div class="col s12 m6 grid">
<figure class="effect-marley">
<img src="../../../source/images/9.jpg" alt="img11">
<figcaption>
<h5><b>New<span> City 2</span></b></h5>
<p>Milo went to the woods. He took a fun ride and never came back.</p>
<a href="#">View more</a>
</figcaption>     
</figure>
</div>
</div>
<div class="col l3">
<div class="col s12 m6 grid">
<figure class="effect-marley">
<img src="../../../source/images/11.jpg" alt="img11">
<figcaption>
<h5><b>Design<span> 2</span></b></h5>
<p>Milo went to the woods. He took a fun ride and never came back.</p>
<a href="#">View more</a>
</figcaption>     
</figure>
</div>
</div>
<div class="col l3">
<div class="col s12 m6 grid">
<figure class="effect-marley">
<img src="../../../source/images/13.jpg" alt="img11">
<figcaption>
<h5><b>New<span>City 3</span></b></h5>
<p>Milo went to the woods. He took a fun ride and never came back.</p>
<a href="#">View more</a>
</figcaption>     
</figure>
</div>
</div>
<!--
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/2.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/1.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/3.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/4.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/5.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/6.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/7.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/8.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/9.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/10.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/11.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/12.jpg">
<img class="materialboxed col l3" height="200" width="250" src="../../../source/images/13.jpg">
-->
</div>
 <?php require_once '../pieds.php'; ?>
</body>
</html>
    <?php require_once '../../../include/script.php'; ?>