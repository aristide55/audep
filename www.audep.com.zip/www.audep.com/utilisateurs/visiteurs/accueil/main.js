$('h2').on('mouseover', function() {
    $('#cont').attr('style', "background: url('../../../source/images/" + this.dataset.img + ".jpg');background-size: 100%;background-attachment: fixed;background-repeat: no-repeat;background-position: 0 -5cm;")
})