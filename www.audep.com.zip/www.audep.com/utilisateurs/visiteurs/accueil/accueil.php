<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>AUDEP | Accueil</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <?php require_once '../../../include/link.php'; ?>
    <?php require_once '../../../include/icones.php'; ?>
    <link rel="stylesheet" href="style.css">
</head>

<body class="row white grey-text text-darken-3 scroller">
    <div id="fond">

    </div>
    <?php require_once '../menu.php'; ?>
    <div class="row"></div>
    <div class="col l1" id="social">
        <a href="#" class="tooltipped" data-tooltip="twitter" data-delay="50" data-position="right"><i class="fa fa-twitter fa-2x white-text animated pulseWarning"></i></a><br>
        <a href="#" class="tooltipped" data-tooltip="instagram" data-delay="50" data-position="right"><i class="fa fa-instagram fa-2x white-text"></i></a><br>
        <a href="#" class="tooltipped" data-tooltip="facebook" data-delay="50" data-position="right"><i class="fa fa-facebook fa-2x white-text"></i></a><br>
        <a href="#" class="tooltipped" data-tooltip="skype" data-delay="50" data-position="right"><i class="fa fa-skype fa-2x white-text"></i></a><br>
        <a href="#" class="tooltipped" data-tooltip="email" data-delay="50" data-position="right"><i class="fa fa-envelope fa-2x white-text"></i></a><br>
    </div>
    <div class="col l10 center grey-text text-lighten-1" id="logo">
        <span class="fa-8x white-text">AUDEP</span><br> 
    <span class="fa-4x white-text flow-text"><i>International </i></span><span
            class="fa-4x flow-text white-text"><b> SARL</b></><br></span>
        <span class="col l12 fa-2x flow-text white-text"><b>Architecture, Urbanisme, Design, Engineering et Paysage</b></span>
    </div>
</div>

    <div class="col l12" id="cont">
    <div class="col l5" >
   <h2 data-img="2" id="archi" class="white-text col l12 fa-3x center grey darken-3" style="margin-top:1.3cm"><b>ARCHITECTURE</b></h2> 
   <h2 data-img="9" id="urb" class="white-text col l12 fa-3x center brown" style="margin-left:5cm"><b>URBANISME</b></h2>
   <h2 data-img="11" id="des" class="white-text col l12 fa-3x center cyan" style="margin-left:10cm"><b>DESIGN</b></h2>    
   <h2 data-img="1" id="eng" class="grey-text col l12 fa-3x center white" style="margin-left:15cm"><b>ENGINEERING</b></h2>    
   <h2 data-img="10" id="des" class="white-text col l12 fa-3x center  light-green darken-3" style="margin-left:20cm"><b>PAYSAGE</b></h2>    
    </div>
</div>
<?php require_once '../pieds.php'; ?>
    
       <?php require_once '../../../include/script.php'; ?>

    <script src="main.js"></script>

</body>

</html>