<div class="menu-fixed">
<div id="menu" class="col l6 offset-l6">
        <a class='translation-button btn z-depth-0' style="background-color:rgba(0,0,0,0);font-weight:bold" href='../accueil'>Accueil</a>
        <a class='translation-button btn z-depth-0' style="background-color:rgba(0,0,0,0);font-weight:bold" href='#'
            data-activates='projets'>projets<i class="mdi-navigation-expand-more"></i> </a>

        <!-- translation Structure -->
        <ul style="background-color:rgba(255,255,255,0.99);font-weight:bold;color:grey" id='projets' class='dropdown-content'>
            <li><a class="grey-text" href="../projet/public.php">Publics</a></li>
            <li><a class="grey-text" href="../projet/residence.php">Résidence</a></li>
            <li><a class="grey-text" href="../projet/commerce.php">Commerce & Banque</a></li>
            <li><a class="grey-text" href="../projet/headoffice.php">Head office</a></li>

        </ul>

        <a class='translation-button btn z-depth-0' style="background-color:rgba(0,0,0,0);font-weight:bold" href='#'
            data-activates='apropos'>A propos <i class="mdi-navigation-expand-more"></i> </a>

        <ul style="background-color:rgba(255,255,255,0.99);font-weight:bold;color:grey" id='apropos' class='dropdown-content'>
            <li><a class="grey-text" href="../apropos/motdg.php">Agence</a></li>
            <li><a class="grey-text" href="../apropos/equipe.php">Equipe</a></li>

        </ul>

        <a class='translation-button btn z-depth-0' style="background-color:rgba(0,0,0,0);font-weight:bold" href='#'>Contact</a>

    </div>
</div>
