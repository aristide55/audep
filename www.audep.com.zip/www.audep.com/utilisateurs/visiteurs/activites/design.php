
<div id="design" class="col l12">
<div class="col l5" id="des">
   <h2 class="white-text col l12 fa-3x center cyan"><b>DESIGN</b></h2>    
</div>
    <div class="col l7 s12 m12" style="background-color:#00bbd49e" id="cards">
            <div class="col l12">
                <div class="card z-depth-0" style="background-color:rgba(0,0,0,0)">
                    <div class="card-content white-text">
                        <span class="card-title"><b class="">CONCEPTION</b></span>
                        <ol>
                            <li>Conception des espaces de bureaux</li>
                            <li>Conception des espaces commerciaux(banques, assurances)</li>
                            <li>Boutiques de luxe</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
            <div class="col l12">
                <div class="card z-depth-0" style="background-color:rgba(0,0,0,0)">
                    <div class="card-content white-text">
                        <span class="card-title"> <b class="">AGENCEMENT DES ESPACES</b></span>
                        <ol>
                            <li>Agencement des espaces de bureaux</li>
                            <li>Agencement des bureaux</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
            <div class="col l12">
                <div class="card z-depth-0" style="background-color:rgba(0,0,0,0)">
                    <div class="card-content white-text">
                        <span class="card-title"> <b class="">DESIGN DE MOBILIERS</b></span>
                        <ol>
                            <li>Design de mobiliers divers (tables de travail, armoirs de rangements, cloisons de séparation)</li>
                            <li>Redaction des marchés</li>
                            <li>Analyse des dossiers d'appels d'offre</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>