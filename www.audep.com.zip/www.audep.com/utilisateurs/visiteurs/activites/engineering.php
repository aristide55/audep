<div id="engineering" class="col l12">
<div class="col l5" id="eng">
   <h2 class="grey-text col l12 fa-3x center white"><b>ENGINEERING</b></h2>    
</div>
    <div class="col l7 s12 m12 white" id="cards">
            <div class="col l12">
                <div class="card white z-depth-0">
                    <div class="card-content grey-text text-darken-3">
                        <span class="card-title"><b class="">ETUDE TECHNIQUE</b></span>
                        <ol>
                            <li>Etude des tracers routiers</li>
                            <li>Dimension des reseaux</li>
                            <li>Electrification rurales</li>
                            <li>Adduction d'eau</li>
                            <li>Assainissements et drainages</li>
                            <li>Evaluation de l'etat de dégradation des VRD</li>
                            <li>Structure en beton armés</li>
                            <li>Charpentes métallique</li>
                            <li>Charpente en bois</li>
                            <li>Géo-Béton</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
            <div class="col l12">
                <div class="card white z-depth-0">
                    <div class="card-content grey-text text-darken-3">
                        <span class="card-title"> <b class="">MAITRISE D'OUVRAGE</b></span>
                        <ol>
                            <li>Elaboration des programmes</li>
                            <li>Redaction des marchés</li>
                            <li>Analyse des dossiers d'appels d'offre</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
