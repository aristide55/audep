
<div id="urbanisme" class="col l12">
<div class="col l5" id="urb">
   <h2 class="white-text col l12 fa-3x center brown"><b>URBANISME</b></h2>    
</div>
    <div class="col l7 s12 m12 white" id="cards">
            <div class="col l12">
                <div class="card white z-depth-0">
                    <div class="card-content grey-text text-darken-3">
                        <span class="card-title"><b class="">PLANIFICATION URBAINE</b></span>
                        <ol>
                            <li>Etudes prospectives (imographies, habitat, équipements publics, transport ...)</li>
                            <li>Programation et dimensionnement des équipement urbains</li>
                            <li>Schema Directeur d'amenagement et d'urbanisme (SDU)</li>
                            <li>Plan Urbanisme Directeur (PDU)</li>
                            <li>Programme des investissements</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
            <div class="col l12">
                <div class="card white z-depth-0">
                    <div class="card-content grey-text text-darken-3">
                        <span class="card-title"> <b class="">AMENAGEMENT URBAIN</b></span>
                        <ol>
                            <li>Plan de lotissemeent et plan de details</li>
                            <li>Plan d'aménagement foncier</li>
                            <li>Plan d'aménagement sectoriels</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
            <div class="col l12">
                <div class="card white z-depth-0">
                    <div class="card-content grey-text text-darken-3">
                        <span class="card-title"> <b class="">GENIE MUNICIPAL & GESTION URBAINE</b></span>
                        <ol>
                            <li>Gestion informatisée des lotissements</li>
                            <li>Enquêtes et inventaires fonciers</li>
                            ...
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>