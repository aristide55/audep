
<div id="architecture" class="col l12">
<div class="col l5" id="archi">
   <h2 class="white-text col l12 fa-3x center grey darken-3"><b>ARCHITECTURE</b></h2>    
</div>
    <div class="col l7 s12 m12 " style="background-color:rgba(0,0,0,0.4)" id="cards">
            <div class="col l12">
                <div class="card  z-depth-0" style="background-color:rgba(0,0,0,0)">
                    <div class="card-content white-text">

                        <span class="card-title"><b class="">ETUDE ARCHITECTURALE</b></span>
                        <ol>
                            <li>Conception architecturale des batiments publics et privés</li>
                            <li>Education, santé, sécurité</li>
                            <li>Equipements socioculturels, bureaux</li>
                            <li>Batiments commerciaux</li>
                            <li>Equipements publics marchands : gares routiers, marchés</li>
                            <li>Abattoirs</li>
                            ...
                        </ol>
                        
                    </div>
                </div>
            </div>
            <div class="col l12">
                <div class="card  z-depth-0" style="background-color:rgba(0,0,0,0)" >
                    <div class="card-content white-text">
                        <span class="card-title"> <b class="">MAITRISE D'OEUVRE TECHNIQUE</b></span>
                        <ol>
                            <li>Conception des ouvrages</li>
                            <li>Suivi et pilotage des chantiers</li>
                            <li>Conception Architecturale des batiments publics et privés</li>
                            ...
                        </ol>
                       
                    </div>
                </div>
            </div>
            <div class="col l12">
                <div class="card  z-depth-0" style="background-color:rgba(0,0,0,0)">
                    <div class="card-content white-text">
                        <span class="card-title"> <b class="">MAITRISE D'OUVRAGES DELEGUE</b></span>
                        <ol>
                            <li>Elaboration des programmes</li>
                            <li>Redaction des marchés</li>
                            <li>Analyse des dossiers d'appels d'offre</li>
                            ...
                        </ol>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
</div>