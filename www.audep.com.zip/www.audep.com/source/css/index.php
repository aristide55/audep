<?php
header('location:../vues/acceuil.php');
strtolower()

?>